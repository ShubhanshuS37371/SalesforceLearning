import { LightningElement, track, wire, api } from 'lwc';
import getEventTiles from '@salesforce/apex/DFDFW_TILECONFIG_ServicesController.getEventTiles';
import TILES from '@salesforce/resourceUrl/DFDFW_Service_Tiles';
import TREE_PLANTING from '@salesforce/resourceUrl/DFDFW_TreePlanting';
import { NavigationMixin } from 'lightning/navigation';

export default class LwcDFDFWServiceTileMenu extends NavigationMixin(LightningElement) {
    @track tiles = [];

    URL;
    connectedCallback() {
        this.URL = window.location.origin;
        console.log('Base URL: ' + this.URL);
    }

    @wire(getEventTiles)
    wiredEventTiles({ error, data }) {
        if (data) {
            console.log('Fetched Data: ', data);
            this.tiles = data.map(tile => ({
                id: tile.Id,
                label: tile.DFDFW_Tile_Name__c,
                //eventImageURL: tile.DFDFW_Image_URL__c ? `${TILES}/${tile.DFDFW_Image_URL__c}` : '', 
                eventImageURL: tile.DFDFW_Image_URL__c ? `${TILES}/images/${tile.DFDFW_Image_URL__c}` : '',
                //eventImageURL: TREE_PLANTING,
                subheading: tile.DFDFW_Tile_Subheading__c,
                communityURL: tile.DFDFW_Community_Page_Url__c
            }));
        } else if (error) {
            console.error('Error fetching event tiles:', error);
        }
        console.log('Processed Tiles: ', JSON.stringify(this.tiles));
    }

    handleTileClick(event) {
        const tileId = event.currentTarget.dataset.id; 
        const selectedTile = this.tiles.find(tile => tile.id === tileId);

        if (!selectedTile) {
            console.error('Tile not found.');
            return;
        }

        const { label: eventtype, communityURL } = selectedTile;

        if (!communityURL) {
            console.error('Community URL is missing for this tile.');
            return;
        }

        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: `${communityURL}?eventType=${eventtype}`
            }
        });

        this.dispatchEvent(new CustomEvent('tileclick', {
            detail: { eventtype }
        }));
    }
}